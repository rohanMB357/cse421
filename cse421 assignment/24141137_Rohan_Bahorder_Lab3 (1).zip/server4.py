import socket


def calculate_salary(hours):
    if hours <= 40:
        return hours * 200
    else:
        return 8000 + (hours - 40) * 300


server = socket.socket()
server.bind(("0.0.0.0", 5001))  
server.listen(5)
print("Wait for client4")


conn, addr = server.accept()
print(f"Client4 connected: {addr[0]}")

while True:
    data = conn.recv(1024).decode()
    if not data or data.lower() == "exit":
        print(f"Client {addr[0]} not connected")
        break

    print(f"Message from {addr[0]}: {data}")  

    try:
        hours = float(data)
        salary = calculate_salary(hours)
        response = f"Salary: Tk {salary}"
    except ValueError:
        response = "Invalid input"

    conn.send(response.encode())

conn.close()
server.close()
