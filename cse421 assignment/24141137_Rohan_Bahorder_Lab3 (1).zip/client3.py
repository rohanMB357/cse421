import socket

client = socket.socket()
client.connect(("localhost", 5000))
print("Connected server3")

while True:
    msg = input("type 'exit' to quit ")
    client.send(msg.encode())
    
    if msg.lower() == "exit":
        break

    response = client.recv(1024).decode()
    print("Server response:", response)

client.close()
