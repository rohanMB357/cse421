import socket

client = socket.socket()
client.connect(("localhost", 5001))
print("Connected  server4")

while True:
    msg = input("Enter hour ")
    client.send(msg.encode())
    
    if msg.lower() == "exit":
        break

    response = client.recv(1024).decode()
    print("Server4 response:", response)

client.close()
