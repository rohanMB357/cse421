import socket

server = socket.socket()
server.bind(("0.0.0.0", 5000))
server.listen(5)
print("Server start")

while True:
    conn, addr = server.accept()
    device_name = conn.recv(1024).decode()

    print("Client connected:")
    print("IP:", addr[0])
    print("Device Name:", device_name)

    conn.close()
