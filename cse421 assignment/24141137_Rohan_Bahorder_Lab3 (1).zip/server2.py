import socket

def count_vowels(message):
    vowels = "aeiouAEIOU"
    return sum(1 for ch in message if ch in vowels)


server = socket.socket()
server.bind(("0.0.0.0", 5000))
server.listen(5)
print("Server started... Waiting for client.")


conn, addr = server.accept()
print(f"Client connected: {addr[0]}")

while True:
    data = conn.recv(1024).decode()
    if not data or data.lower() == "exit":
        print("Client disconnected.")
        break

    print("Message from client:", data)
    vowel_count = count_vowels(data)
    
    if vowel_count == 0:
        response = "Not enough vowels"
    elif vowel_count <= 2:
        response = "Enough vowels I guess"
    else:
        response = "Too many vowels"

    conn.send(response.encode())

conn.close()
server.close()
