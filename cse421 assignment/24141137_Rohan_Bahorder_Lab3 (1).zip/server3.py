import socket
import threading


def count_vowels(message):
    vowels = "aeiouAEIOU"
    return sum(1 for ch in message if ch in vowels)


def handle_client(conn, addr):
    print(f"client3 connected: {addr[0]}")
    while True:
        try:
            data = conn.recv(1024).decode()
            if not data or data.lower() == "exit":
                print(f"client3 {addr[0]} disconnected.")
                break

            
            print(f"Message from {addr[0]}: {data}")

           
            vowel_count = count_vowels(data)
            if vowel_count == 0:
                response = "Not enough vowels"
            elif vowel_count <= 2:
                response = "Enough vowels I guess"
            else:
                response = "Too many vowels"

           
            conn.send(response.encode())
        except ConnectionResetError:
            print(f"client3 {addr[0]} disconnected unexpectedly.")
            break

    conn.close()


server = socket.socket()
server.bind(("0.0.0.0", 5000))
server.listen(5)
print("Multi-threaded server started... Waiting for client3")


while True:
    conn, addr = server.accept()
    threading.Thread(target=handle_client, args=(conn, addr)).start()
