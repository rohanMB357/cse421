import socket

client = socket.socket()
client.connect(("localhost", 5000))   

device_name = "PC1"
client.send(device_name.encode())

client.close()
